import { useRef, useEffect, useState } from 'react';
import { Heart, User, Calendar, Building2, ArrowRight } from 'lucide-react';

interface Service {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
}

const services: Service[] = [
  {
    icon: <Heart size={32} />,
    title: 'Wedding Photography',
    description:
      'Capturing your special day with elegance and artistry. From intimate ceremonies to grand celebrations.',
    features: [
      'Full day coverage',
      'Engagement session',
      'Professional editing',
      'Online gallery',
    ],
  },
  {
    icon: <User size={32} />,
    title: 'Portrait Sessions',
    description:
      'Professional portraits that showcase your unique personality. Perfect for individuals, couples, and families.',
    features: [
      'Studio or location',
      'Wardrobe consultation',
      'Multiple outfit changes',
      'High-resolution images',
    ],
  },
  {
    icon: <Calendar size={32} />,
    title: 'Event Coverage',
    description:
      'Comprehensive documentation of your important events. Corporate gatherings, parties, and milestones.',
    features: [
      'Candid moments',
      'Group photos',
      'Same-day previews',
      'Full coverage',
    ],
  },
  {
    icon: <Building2 size={32} />,
    title: 'Commercial Work',
    description:
      'High-quality imagery for brands and businesses. Product photography, marketing materials, and more.',
    features: [
      'Product photography',
      'Brand storytelling',
      'Marketing assets',
      'Licensing options',
    ],
  },
];

const Services = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-24 lg:py-32 bg-[#1a1a1a]/50"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`section-label inline-block mb-4 transition-all duration-500 ${
              isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
            }`}
          >
            My Services
          </span>
          <h2
            className={`text-4xl md:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
            style={{
              transitionDelay: '200ms',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            Professional Photography Solutions
          </h2>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`relative group p-8 rounded-lg bg-white/5 border border-white/10 transition-all duration-500 ${
                isVisible
                  ? 'translate-y-0 opacity-100'
                  : 'translate-y-12 opacity-0'
              } ${
                hoveredIndex === index
                  ? 'bg-white/10 border-gold/50 -translate-y-2'
                  : ''
              }`}
              style={{
                transitionDelay: `${400 + index * 150}ms`,
                transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
                transform: isVisible
                  ? hoveredIndex === index
                    ? 'translateY(-8px)'
                    : 'translateY(0)'
                  : 'translateY(48px)',
              }}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* Icon */}
              <div
                className={`w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center text-gold mb-6 transition-all duration-500 ${
                  hoveredIndex === index ? 'scale-110 bg-gold/20' : ''
                }`}
              >
                {service.icon}
              </div>

              {/* Title */}
              <h3 className="text-2xl font-bold text-white mb-4 font-['Cormorant_Garamond']">
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-white/60 mb-6 leading-relaxed">
                {service.description}
              </p>

              {/* Features */}
              <ul className="space-y-2 mb-8">
                {service.features.map((feature) => (
                  <li
                    key={feature}
                    className="flex items-center gap-2 text-white/70 text-sm"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-gold" />
                    {feature}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  document
                    .querySelector('#contact')
                    ?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-gold group/link"
              >
                <span className="relative">
                  Learn More
                  <span className="absolute -bottom-1 left-0 w-0 h-px bg-gold transition-all duration-300 group-hover/link:w-full" />
                </span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover/link:translate-x-1" />
              </a>

              {/* Hover glow */}
              <div
                className={`absolute inset-0 rounded-lg transition-opacity duration-500 pointer-events-none ${
                  hoveredIndex === index ? 'opacity-100' : 'opacity-0'
                }`}
                style={{
                  boxShadow: '0 0 40px rgba(201, 169, 98, 0.15)',
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
