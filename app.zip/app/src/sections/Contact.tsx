import { useState, useRef, useEffect } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';

interface ContactInfo {
  icon: React.ReactNode;
  label: string;
  value: string;
  href: string;
}

const contactInfo: ContactInfo[] = [
  {
    icon: <Mail size={24} />,
    label: 'Email',
    value: 'hello@elenamitchell.com',
    href: 'mailto:hello@elenamitchell.com',
  },
  {
    icon: <Phone size={24} />,
    label: 'Phone',
    value: '+1 (555) 123-4567',
    href: 'tel:+15551234567',
  },
  {
    icon: <MapPin size={24} />,
    label: 'Location',
    value: 'New York City, NY',
    href: '#',
  },
];

const Contact = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubmitted(true);
    setFormData({ name: '', email: '', message: '' });

    // Reset success message after 5 seconds
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span
            className={`section-label inline-block mb-4 transition-all duration-500 ${
              isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
            }`}
          >
            Get In Touch
          </span>
          <h2
            className={`text-4xl md:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
            style={{
              transitionDelay: '200ms',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            Let's Create Something
            <br />
            <span className="text-gold">Beautiful Together</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Form */}
          <div
            className={`lg:col-span-3 transition-all duration-700 ${
              isVisible ? 'translate-x-0 opacity-100' : '-translate-x-12 opacity-0'
            }`}
            style={{
              transitionDelay: '400ms',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name Field */}
              <div className="relative">
                <label
                  className={`absolute left-4 transition-all duration-300 pointer-events-none ${
                    focusedField === 'name' || formData.name
                      ? '-top-2.5 text-xs text-gold bg-[#0f0f0f] px-2'
                      : 'top-4 text-white/50'
                  }`}
                >
                  Your Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  onFocus={() => setFocusedField('name')}
                  onBlur={() => setFocusedField(null)}
                  required
                  className={`w-full px-4 py-4 bg-white/5 border rounded-lg text-white outline-none transition-all duration-300 ${
                    focusedField === 'name'
                      ? 'border-gold shadow-[0_0_20px_rgba(201,169,98,0.2)]'
                      : 'border-white/20 hover:border-white/40'
                  }`}
                />
              </div>

              {/* Email Field */}
              <div className="relative">
                <label
                  className={`absolute left-4 transition-all duration-300 pointer-events-none ${
                    focusedField === 'email' || formData.email
                      ? '-top-2.5 text-xs text-gold bg-[#0f0f0f] px-2'
                      : 'top-4 text-white/50'
                  }`}
                >
                  Your Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  onFocus={() => setFocusedField('email')}
                  onBlur={() => setFocusedField(null)}
                  required
                  className={`w-full px-4 py-4 bg-white/5 border rounded-lg text-white outline-none transition-all duration-300 ${
                    focusedField === 'email'
                      ? 'border-gold shadow-[0_0_20px_rgba(201,169,98,0.2)]'
                      : 'border-white/20 hover:border-white/40'
                  }`}
                />
              </div>

              {/* Message Field */}
              <div className="relative">
                <label
                  className={`absolute left-4 transition-all duration-300 pointer-events-none ${
                    focusedField === 'message' || formData.message
                      ? '-top-2.5 text-xs text-gold bg-[#0f0f0f] px-2'
                      : 'top-4 text-white/50'
                  }`}
                >
                  Your Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  onFocus={() => setFocusedField('message')}
                  onBlur={() => setFocusedField(null)}
                  required
                  rows={5}
                  className={`w-full px-4 py-4 bg-white/5 border rounded-lg text-white outline-none transition-all duration-300 resize-none ${
                    focusedField === 'message'
                      ? 'border-gold shadow-[0_0_20px_rgba(201,169,98,0.2)]'
                      : 'border-white/20 hover:border-white/40'
                  }`}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting || isSubmitted}
                className={`w-full py-4 rounded-lg font-medium flex items-center justify-center gap-2 transition-all duration-500 ${
                  isSubmitted
                    ? 'bg-green-500 text-white'
                    : 'bg-gold text-[#0f0f0f] hover:shadow-[0_0_30px_rgba(201,169,98,0.4)] hover:scale-[1.02]'
                } disabled:cursor-not-allowed`}
              >
                {isSubmitting ? (
                  <div className="w-6 h-6 border-2 border-[#0f0f0f]/30 border-t-[#0f0f0f] rounded-full animate-spin" />
                ) : isSubmitted ? (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    Message Sent!
                  </>
                ) : (
                  <>
                    Send Message
                    <Send className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div
            className={`lg:col-span-2 space-y-6 transition-all duration-700 ${
              isVisible ? 'translate-x-0 opacity-100' : 'translate-x-12 opacity-0'
            }`}
            style={{
              transitionDelay: '600ms',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            {contactInfo.map((info, index) => (
              <a
                key={info.label}
                href={info.href}
                className="group flex items-center gap-4 p-6 bg-white/5 rounded-lg border border-white/10 hover:border-gold/50 hover:bg-white/10 transition-all duration-300 hover:-translate-y-1"
                style={{
                  transitionDelay: `${700 + index * 100}ms`,
                }}
              >
                <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center text-gold group-hover:bg-gold/20 group-hover:scale-110 transition-all duration-300">
                  {info.icon}
                </div>
                <div>
                  <div className="text-sm text-white/50 mb-1">{info.label}</div>
                  <div className="text-white group-hover:text-gold transition-colors duration-300">
                    {info.value}
                  </div>
                </div>
              </a>
            ))}

            {/* Additional Info */}
            <div className="p-6 bg-gradient-to-br from-gold/10 to-transparent rounded-lg border border-gold/20">
              <h4 className="text-lg font-semibold text-white mb-2 font-['Cormorant_Garamond']">
                Response Time
              </h4>
              <p className="text-white/60 text-sm">
                I typically respond within 24 hours. For urgent inquiries, please
                call directly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
