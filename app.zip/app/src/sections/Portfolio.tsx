import { useState, useRef, useEffect } from 'react';
import { ArrowUpRight } from 'lucide-react';

interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  image: string;
  size: 'large' | 'medium' | 'small';
}

const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    title: 'Eternal Love',
    category: 'Wedding',
    image: '/portfolio-wedding-1.jpg',
    size: 'large',
  },
  {
    id: 2,
    title: 'Natural Beauty',
    category: 'Portrait',
    image: '/portfolio-portrait-1.jpg',
    size: 'medium',
  },
  {
    id: 3,
    title: 'Mountain Serenity',
    category: 'Nature',
    image: '/portfolio-nature-1.jpg',
    size: 'large',
  },
  {
    id: 4,
    title: 'Golden Hour',
    category: 'Portrait',
    image: '/portfolio-portrait-2.jpg',
    size: 'medium',
  },
  {
    id: 5,
    title: 'Corporate Gala',
    category: 'Event',
    image: '/portfolio-event-1.jpg',
    size: 'medium',
  },
  {
    id: 6,
    title: 'Bridal Details',
    category: 'Wedding',
    image: '/portfolio-wedding-2.jpg',
    size: 'small',
  },
  {
    id: 7,
    title: 'Sunset Solitude',
    category: 'Nature',
    image: '/portfolio-nature-2.jpg',
    size: 'large',
  },
  {
    id: 8,
    title: 'Professional Headshot',
    category: 'Portrait',
    image: '/portfolio-portrait-3.jpg',
    size: 'small',
  },
  {
    id: 9,
    title: 'Birthday Celebration',
    category: 'Event',
    image: '/portfolio-event-2.jpg',
    size: 'medium',
  },
];

const categories = ['All', 'Wedding', 'Portrait', 'Event', 'Nature'];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const filteredItems =
    activeCategory === 'All'
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === activeCategory);

  const getGridClass = (size: string) => {
    switch (size) {
      case 'large':
        return 'md:col-span-2 md:row-span-2';
      case 'medium':
        return 'md:col-span-1 md:row-span-1';
      case 'small':
        return 'md:col-span-1 md:row-span-1';
      default:
        return '';
    }
  };

  return (
    <section
      id="portfolio"
      ref={sectionRef}
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <span
            className={`section-label inline-block mb-4 transition-all duration-500 ${
              isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
            }`}
          >
            My Portfolio
          </span>
          <h2
            className={`text-4xl md:text-5xl font-bold text-white transition-all duration-700 ${
              isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
            style={{
              transitionDelay: '200ms',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            Explore My Latest Photography Work
          </h2>
        </div>

        {/* Category Tabs */}
        <div
          className={`flex flex-wrap justify-center gap-4 mb-12 transition-all duration-500 ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
          style={{
            transitionDelay: '400ms',
            transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 text-sm font-medium transition-all duration-300 relative ${
                activeCategory === category
                  ? 'text-gold'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              {category}
              {activeCategory === category && (
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-gold transition-all duration-300" />
              )}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[250px]">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className={`relative group overflow-hidden rounded-lg cursor-pointer ${getGridClass(
                item.size
              )} transition-all duration-500 ${
                isVisible
                  ? 'translate-y-0 opacity-100 scale-100'
                  : 'translate-y-8 opacity-0 scale-95'
              }`}
              style={{
                transitionDelay: `${500 + index * 100}ms`,
                transitionTimingFunction: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
              }}
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              {/* Image */}
              <img
                src={item.image}
                alt={item.title}
                className={`w-full h-full object-cover transition-transform duration-700 ${
                  hoveredItem === item.id ? 'scale-110' : 'scale-100'
                }`}
              />

              {/* Overlay */}
              <div
                className={`absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/50 to-transparent transition-opacity duration-500 ${
                  hoveredItem === item.id ? 'opacity-90' : 'opacity-0'
                }`}
              />

              {/* Content */}
              <div
                className={`absolute inset-0 flex flex-col justify-end p-6 transition-all duration-500 ${
                  hoveredItem === item.id
                    ? 'translate-y-0 opacity-100'
                    : 'translate-y-4 opacity-0'
                }`}
              >
                <span className="text-gold text-sm mb-2">{item.category}</span>
                <h3 className="text-xl font-bold text-white mb-2 font-['Cormorant_Garamond']">
                  {item.title}
                </h3>
                <div className="flex items-center gap-2 text-white/80 text-sm group/link">
                  <span>View Project</span>
                  <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover/link:translate-x-1 group-hover/link:-translate-y-1" />
                </div>
              </div>

              {/* Corner accent */}
              <div
                className={`absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-gold transition-all duration-500 ${
                  hoveredItem === item.id
                    ? 'opacity-100 scale-100'
                    : 'opacity-0 scale-50'
                }`}
              />
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div
          className={`text-center mt-12 transition-all duration-500 ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
          style={{
            transitionDelay: '1200ms',
            transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <button className="btn-secondary inline-flex items-center gap-2 group">
            View All Projects
            <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
