import { useEffect, useRef, useState } from 'react';
import { Play, ArrowRight } from 'lucide-react';

const Hero = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsLoaded(true);
    
    const handleScroll = () => {
      if (imageRef.current) {
        const scrollY = window.scrollY;
        const parallaxValue = scrollY * 0.4;
        const brightnessValue = Math.max(0.4, 1 - scrollY * 0.002);
        imageRef.current.style.transform = `translateY(${parallaxValue}px) scale(${1 + scrollY * 0.0002})`;
        imageRef.current.style.filter = `brightness(${brightnessValue})`;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      ref={heroRef}
      className="relative min-h-screen flex items-end pb-20 lg:pb-32 overflow-hidden"
    >
      {/* Background Image */}
      <div
        ref={imageRef}
        className="absolute inset-0 w-full h-full transition-transform duration-100"
        style={{
          willChange: 'transform, filter',
        }}
      >
        <img
          src="/hero-bg.jpg"
          alt="Photography background"
          className="w-full h-full object-cover"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f0f0f]/80 to-transparent" />
      </div>

      {/* Play Button */}
      <button
        onClick={() => setShowVideo(true)}
        className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 group transition-all duration-700 ${
          isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
        }`}
        style={{ transitionDelay: '1500ms' }}
      >
        <div className="relative">
          {/* Rotating diamond */}
          <div className="w-24 h-24 border border-gold/50 rotate-45 animate-[spin_20s_linear_infinite] group-hover:animate-[spin_0.5s_linear_infinite] transition-all duration-300" />
          {/* Inner circle */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full border border-gold flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:bg-gold/10">
              <Play className="w-6 h-6 text-gold fill-gold ml-1" />
            </div>
          </div>
          {/* Glow ring */}
          <div className="absolute inset-0 rounded-full animate-ping opacity-20">
            <div className="w-full h-full border border-gold rounded-full" />
          </div>
        </div>
      </button>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          {/* Headline */}
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-8">
            {['Capturing', "Life's Precious", 'Moments'].map((line, lineIndex) => (
              <span
                key={lineIndex}
                className={`block overflow-hidden ${lineIndex === 1 ? 'ml-8 md:ml-16' : ''} ${
                  lineIndex === 2 ? 'ml-16 md:ml-32' : ''
                }`}
              >
                <span
                  className={`block transition-all duration-800 ${
                    isLoaded
                      ? 'translate-y-0 opacity-100'
                      : 'translate-y-full opacity-0'
                  }`}
                  style={{
                    transitionDelay: `${500 + lineIndex * 150}ms`,
                    transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
                  }}
                >
                  {line}
                </span>
              </span>
            ))}
          </h1>

          {/* Description */}
          <p
            className={`text-lg md:text-xl text-white/80 max-w-xl mb-10 leading-relaxed transition-all duration-600 ${
              isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
            style={{
              transitionDelay: '1000ms',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            Professional photography services for portraits, weddings, and special 
            occasions. Creating timeless memories through artistic vision.
          </p>

          {/* CTAs */}
          <div
            className={`flex flex-wrap gap-4 transition-all duration-500 ${
              isLoaded ? 'translate-x-0 opacity-100' : '-translate-x-12 opacity-0'
            }`}
            style={{
              transitionDelay: '1200ms',
              transitionTimingFunction: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
            }}
          >
            <button
              onClick={() => scrollToSection('#portfolio')}
              className="btn-primary flex items-center gap-2 group"
            >
              View Portfolio
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => scrollToSection('#contact')}
              className="btn-secondary"
            >
              Book a Session
            </button>
          </div>
        </div>
      </div>

      {/* Video Modal */}
      {showVideo && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm"
          onClick={() => setShowVideo(false)}
        >
          <div className="relative w-full max-w-4xl mx-4 aspect-video bg-[#1a1a1a] rounded-lg overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-white/60 text-lg">Video showcase coming soon</p>
            </div>
            <button
              onClick={() => setShowVideo(false)}
              className="absolute top-4 right-4 text-white/60 hover:text-white transition-colors"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </section>
  );
};

export default Hero;
