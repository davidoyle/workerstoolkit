import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Award, Users, Camera } from 'lucide-react';

interface StatProps {
  icon: React.ReactNode;
  value: number;
  suffix: string;
  label: string;
  isVisible: boolean;
}

const AnimatedStat = ({ icon, value, suffix, label, isVisible }: StatProps) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number;
    const duration = 2000;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * value));

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isVisible, value]);

  return (
    <div className="flex items-center gap-4 p-4 bg-white/5 rounded-lg backdrop-blur-sm">
      <div className="w-12 h-12 flex items-center justify-center rounded-full bg-gold/10 text-gold">
        {icon}
      </div>
      <div>
        <div className="text-3xl font-bold text-white font-['Cormorant_Garamond']">
          {count}
          {suffix}
        </div>
        <div className="text-sm text-white/60">{label}</div>
      </div>
    </div>
  );
};

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [imageRotation, setImageRotation] = useState(5);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        const scrollProgress = 1 - rect.top / window.innerHeight;
        const rotation = 5 - scrollProgress * 10;
        setImageRotation(Math.max(-5, Math.min(5, rotation)));
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const stats = [
    { icon: <Camera size={24} />, value: 15, suffix: '+', label: 'Years Experience' },
    { icon: <Users size={24} />, value: 500, suffix: '+', label: 'Happy Clients' },
    { icon: <Award size={24} />, value: 50, suffix: '+', label: 'Awards Won' },
  ];

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="order-2 lg:order-1">
            {/* Label */}
            <div
              className={`flex items-center gap-4 mb-6 transition-all duration-600 ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
              }`}
              style={{ transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)' }}
            >
              <span className="section-label">About Me</span>
              <span className="flex-1 h-px bg-gold/30 max-w-[100px]" />
            </div>

            {/* Headline */}
            <h2
              className={`text-4xl md:text-5xl font-bold text-white mb-8 leading-tight transition-all duration-700 ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
              }`}
              style={{
                transitionDelay: '200ms',
                transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            >
              Hello, I'm{' '}
              <span className="text-gold">Elena Mitchell</span>
            </h2>

            {/* Body */}
            <div
              className={`space-y-4 text-white/70 leading-relaxed mb-8 transition-all duration-600 ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
              }`}
              style={{
                transitionDelay: '400ms',
                transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
              }}
            >
              <p>
                With over 15 years of experience capturing life's most meaningful moments, 
                I bring a blend of artistic vision and technical expertise to every session.
              </p>
              <p>
                My approach combines candid emotion with carefully crafted composition, 
                ensuring each photograph tells a unique story. Whether it's the joy of a 
                wedding day, the confidence of a professional portrait, or the beauty of 
                nature, I strive to create images that resonate.
              </p>
              <p>
                Based in New York City, I work with clients worldwide, bringing their 
                visions to life through the art of photography.
              </p>
            </div>

            {/* CTA */}
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className={`inline-flex items-center gap-2 text-gold hover:gap-4 transition-all duration-300 group ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
              }`}
              style={{
                transitionDelay: '600ms',
                transitionTimingFunction: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
              }}
            >
              <span className="relative">
                Read More About My Journey
                <span className="absolute -bottom-1 left-0 w-full h-px bg-gold transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
              </span>
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </div>

          {/* Image */}
          <div className="order-1 lg:order-2 relative">
            <div
              className={`relative transition-all duration-1000 ${
                isVisible ? 'translate-x-0 opacity-100' : 'translate-x-24 opacity-0'
              }`}
              style={{
                transitionDelay: '200ms',
                transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
                transform: `perspective(1000px) rotateY(${imageRotation}deg)`,
              }}
            >
              <div className="relative aspect-[3/4] rounded-lg overflow-hidden">
                <img
                  src="/photographer-portrait.jpg"
                  alt="Elena Mitchell - Photographer"
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                />
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f]/40 to-transparent" />
              </div>

              {/* Decorative frame */}
              <div className="absolute -top-4 -right-4 w-full h-full border border-gold/30 rounded-lg -z-10" />
              <div className="absolute -bottom-4 -left-4 w-full h-full border border-gold/20 rounded-lg -z-10" />
            </div>

            {/* Stats */}
            <div
              className={`absolute -bottom-8 left-1/2 -translate-x-1/2 w-[90%] grid grid-cols-3 gap-2 transition-all duration-700 ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'
              }`}
              style={{
                transitionDelay: '800ms',
                transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            >
              {stats.map((stat) => (
                <AnimatedStat
                  key={stat.label}
                  {...stat}
                  isVisible={isVisible}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
